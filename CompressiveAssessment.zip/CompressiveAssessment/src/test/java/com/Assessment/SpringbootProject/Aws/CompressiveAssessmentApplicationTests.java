package com.Assessment.SpringbootProject.Aws;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompressiveAssessmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
