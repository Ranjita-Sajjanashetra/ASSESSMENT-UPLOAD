package com.Assessment.SpringbootProject.Aws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompressiveAssessmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(CompressiveAssessmentApplication.class, args);
	}

}
