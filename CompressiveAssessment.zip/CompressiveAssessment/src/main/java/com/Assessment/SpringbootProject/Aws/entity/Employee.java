package com.Assessment.SpringbootProject.Aws.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.Id;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Employee {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;

	public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
	
}
public String getName() {
	return Name;
}
public int getSalary() {
	return Salary ;
}
public String getDesignation() {
	return Designation;
}
public void setName(String Name) {
	this.Name = Name;
}
public void setSalary(int Salary) {
	this.Salary = Salary;
}
public void setDesignation(String Designation) {
	this.Designation = Designation;
}

     private Long Id;
	 private String Name;
	 private int Salary;
	 private String Designation;
	
	


}
