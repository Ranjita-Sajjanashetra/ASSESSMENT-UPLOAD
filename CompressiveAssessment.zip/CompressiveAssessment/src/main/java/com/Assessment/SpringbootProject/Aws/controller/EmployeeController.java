package com.Assessment.SpringbootProject.Aws.controller;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.Assessment.SpringbootProject.Aws.Exception.EmployeeAlreadyExistsInDataBaseException;
import com.Assessment.SpringbootProject.Aws.entity.Employee;
import com.Assessment.SpringbootProject.Aws.service.ComparatorSort;
import com.Assessment.SpringbootProject.Aws.service.EmployeeService;


import lombok.SneakyThrows;

public class EmployeeController {

	@Autowired private EmployeeService employeeService;
	 @SneakyThrows
	 @PostMapping("/employees")
	 public Employee saveEmployee (
	 @RequestBody Employee employee) throws Exception
	 {
	 List<Employee> employeelist = employeeService.fetchEmployeeList();
	 for (Employee x : employeelist) {
	 if(employee.getId() == x.getId()) {
	 throw new
	EmployeeAlreadyExistsInDataBaseException("This id already exists in the database use a different id!");
	 }
	 }
	 return employeeService.saveEmployee(employee);
	 }

	 @GetMapping("/employees")
	 public List<Employee> fetchEmployeeList()
	 {
	 List<Employee> employeelist = employeeService.fetchEmployeeList();
	 Collections.sort(employeelist,new ComparatorSort());
	 return employeelist;
	 }

	 @PutMapping("/employees/{id}")
	 public Employee
	 updateEmployee(@RequestBody Employee employee,
	 @PathVariable("id") Long Id)
	 {
	 return employeeService.updateEmployee(
	 employee, Id);
	 }



	 @DeleteMapping("/employees/{id}")
	 public String deleteEmployeeById(@PathVariable("id")
	 Long Id)
	 {
	 employeeService.deleteEmployeeById(
	 Id);
	 return "Deleted Successfully";
	 }
	}

